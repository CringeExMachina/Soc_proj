from django.contrib.auth.models import User
from django.test import TestCase


from ..models import Group,Post




class PostModelTest(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.user = User.objects.create_user(username='auth')
        cls.group = Group.objects.create(
            title='Тестовая группа',
            adress='Тестовый слаг',
            description='Тестовое описание',  
        )
        cls.post=Post.objects.create(
            author=cls.user,
            text='Тестовая группа',
        )
    
    def test_models_have_correct_objects_name(self):
        """"Проверяем, что у моделей корректно работает __str__."""
        post=PostModelTest.post
        post_str=str(post)
        
        group=PostModelTest.group
        group_str=str(group)
        
        self.assertEqual(group_str,'Тестовая группа')
        self.assertEqual(post_str,'Тестовая группа')
       
        
    